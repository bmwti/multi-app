import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hackathon-listagem',
  templateUrl: './hackathon-listagem.component.html',
  styleUrls: ['./hackathon-listagem.component.css']
})
export class HackathonListagemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
