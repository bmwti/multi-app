import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-listagem',
  templateUrl: './blog-listagem.component.html',
  styleUrls: ['./blog-listagem.component.css']
})
export class BlogListagemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    
  }

}
