import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-perfil-company',
  templateUrl: './perfil-company.component.html',
  styleUrls: ['./perfil-company.component.css']
})
export class PerfilCompanyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
